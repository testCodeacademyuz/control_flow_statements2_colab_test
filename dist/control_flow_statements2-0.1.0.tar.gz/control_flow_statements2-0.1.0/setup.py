from setuptools import setup

setup(
   name='control_flow_statements2',
   version='0.1.0',
   packages=['control_flow_statements2'],
   description='This is control_flow_statements2 Test',
   install_requires=[
       "requests",
   ]
)